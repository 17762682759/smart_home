/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>
#include "qchartview.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *btn_led;
    QChartView *chartView;
    QLabel *lb_Humi;
    QLabel *lb_Temp;
    QLabel *lb_time;
    QLabel *label;
    QLabel *label_2;
    QLabel *lb_status;
    QLabel *lb_dis;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *lb_lightValue;
    QLabel *lb_curtainAngle;
    QProgressBar *curtainProgressBar;
    QLabel *lb_humandetect;
    QCheckBox *cb_curAutoCtl;
    QPushButton *btn_cur_sub;
    QPushButton *btn_cur_add;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1024, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        btn_led = new QPushButton(centralwidget);
        btn_led->setObjectName(QString::fromUtf8("btn_led"));
        btn_led->setGeometry(QRect(560, 330, 150, 150));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/png/\345\220\212\347\201\257-\345\205\263.png"), QSize(), QIcon::Normal, QIcon::Off);
        btn_led->setIcon(icon);
        btn_led->setIconSize(QSize(150, 255));
        chartView = new QChartView(centralwidget);
        chartView->setObjectName(QString::fromUtf8("chartView"));
        chartView->setGeometry(QRect(20, 120, 480, 350));
        lb_Humi = new QLabel(centralwidget);
        lb_Humi->setObjectName(QString::fromUtf8("lb_Humi"));
        lb_Humi->setGeometry(QRect(420, 180, 67, 20));
        lb_Temp = new QLabel(centralwidget);
        lb_Temp->setObjectName(QString::fromUtf8("lb_Temp"));
        lb_Temp->setGeometry(QRect(30, 180, 67, 17));
        lb_time = new QLabel(centralwidget);
        lb_time->setObjectName(QString::fromUtf8("lb_time"));
        lb_time->setGeometry(QRect(30, 440, 321, 20));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 150, 71, 31));
        QFont font;
        font.setPointSize(15);
        label->setFont(font);
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(430, 150, 71, 31));
        label_2->setFont(font);
        lb_status = new QLabel(centralwidget);
        lb_status->setObjectName(QString::fromUtf8("lb_status"));
        lb_status->setGeometry(QRect(790, 370, 221, 31));
        lb_status->setFont(font);
        lb_dis = new QLabel(centralwidget);
        lb_dis->setObjectName(QString::fromUtf8("lb_dis"));
        lb_dis->setGeometry(QRect(790, 420, 221, 31));
        lb_dis->setFont(font);
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(230, 0, 571, 61));
        QFont font1;
        font1.setPointSize(30);
        label_3->setFont(font1);
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(830, 310, 121, 51));
        QFont font2;
        font2.setPointSize(20);
        label_4->setFont(font2);
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(720, 80, 121, 41));
        label_5->setFont(font2);
        lb_lightValue = new QLabel(centralwidget);
        lb_lightValue->setObjectName(QString::fromUtf8("lb_lightValue"));
        lb_lightValue->setGeometry(QRect(610, 140, 211, 41));
        lb_lightValue->setFont(font);
        lb_curtainAngle = new QLabel(centralwidget);
        lb_curtainAngle->setObjectName(QString::fromUtf8("lb_curtainAngle"));
        lb_curtainAngle->setGeometry(QRect(860, 140, 161, 41));
        lb_curtainAngle->setFont(font);
        curtainProgressBar = new QProgressBar(centralwidget);
        curtainProgressBar->setObjectName(QString::fromUtf8("curtainProgressBar"));
        curtainProgressBar->setGeometry(QRect(660, 200, 251, 51));
        curtainProgressBar->setMaximum(100);
        curtainProgressBar->setValue(0);
        lb_humandetect = new QLabel(centralwidget);
        lb_humandetect->setObjectName(QString::fromUtf8("lb_humandetect"));
        lb_humandetect->setGeometry(QRect(790, 460, 191, 41));
        lb_humandetect->setFont(font);
        cb_curAutoCtl = new QCheckBox(centralwidget);
        cb_curAutoCtl->setObjectName(QString::fromUtf8("cb_curAutoCtl"));
        cb_curAutoCtl->setGeometry(QRect(860, 80, 101, 31));
        cb_curAutoCtl->setFont(font2);
        btn_cur_sub = new QPushButton(centralwidget);
        btn_cur_sub->setObjectName(QString::fromUtf8("btn_cur_sub"));
        btn_cur_sub->setGeometry(QRect(630, 260, 31, 31));
        btn_cur_sub->setFont(font);
        btn_cur_add = new QPushButton(centralwidget);
        btn_cur_add->setObjectName(QString::fromUtf8("btn_cur_add"));
        btn_cur_add->setGeometry(QRect(910, 260, 31, 31));
        btn_cur_add->setFont(font);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1024, 22));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        btn_led->setText(QString());
        lb_Humi->setText(QApplication::translate("MainWindow", "TextLabel", nullptr));
        lb_Temp->setText(QApplication::translate("MainWindow", "TextLabel", nullptr));
        lb_time->setText(QApplication::translate("MainWindow", "TextLabel", nullptr));
        label->setText(QApplication::translate("MainWindow", "\346\270\251\345\272\246", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "\346\271\277\345\272\246", nullptr));
        lb_status->setText(QApplication::translate("MainWindow", "TextLabel", nullptr));
        lb_dis->setText(QApplication::translate("MainWindow", "TextLabel", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "\345\237\272\344\272\216IMX6ULL\347\232\204\346\231\272\350\203\275\345\256\266\345\261\205\347\263\273\347\273\237", nullptr));
        label_4->setText(QApplication::translate("MainWindow", "\346\231\272\350\203\275\345\256\211\351\230\262", nullptr));
        label_5->setText(QApplication::translate("MainWindow", "\346\231\272\350\203\275\347\252\227\345\270\230", nullptr));
        lb_lightValue->setText(QApplication::translate("MainWindow", "TextLabel", nullptr));
        lb_curtainAngle->setText(QApplication::translate("MainWindow", "\347\252\227\345\270\230\350\247\222\345\272\246: 0\302\260", nullptr));
        curtainProgressBar->setFormat(QApplication::translate("MainWindow", "%p", nullptr));
        lb_humandetect->setText(QApplication::translate("MainWindow", "TextLabel", nullptr));
        cb_curAutoCtl->setText(QApplication::translate("MainWindow", "\350\207\252\345\212\250", nullptr));
        btn_cur_sub->setText(QApplication::translate("MainWindow", "-", nullptr));
        btn_cur_add->setText(QApplication::translate("MainWindow", "+", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
