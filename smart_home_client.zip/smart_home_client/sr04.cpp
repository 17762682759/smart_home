#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <QDebug>

#include "sr04.h"
static int fd2;

/* sr04初始化函数 */
void sr04_init(void)
{
    fd2 = open("/dev/sr04", O_RDWR);
    if (fd2 < 0)
    {
        qDebug()<<"open /dev/sr04 failed" << endl;
    }
     qDebug()<<"open /dev/sr04 successfully " << endl;
}

/* sr04读函数 */
int sr04_read(int *dis)
{
    unsigned int ns;
    int ret;

    ret = read(fd2, &ns, 4);

    if (ret < 0)
    {
        qDebug() <<"read /dev/sr04 failed" << endl ;
        return -1;
    }
    *dis = ns*340/2/10000000;
    return 0;
}

int sr04_close()
{
    close(fd2);
}

