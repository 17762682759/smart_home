#ifndef SR04_H
#define SR04_H

void sr04_init(void);
int sr04_read(int *dis);
int sr04_close();

#endif // SR04_H
