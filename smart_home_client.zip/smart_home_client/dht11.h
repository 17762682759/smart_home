#ifndef DHT11_H
#define DHT11_H

// 温湿度数据结构
struct THData {
    double temperature;
    double humidity;
};

void dht11_init(void);
int dht11_read(THData *data);
int dht11_close();




#endif // DHT11_H
