#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <QDebug>

static int fd3;
void sg90_init()
{
    fd3 = open("/dev/sg90", O_RDWR);
    if (fd3 < 0)
    {
        qDebug()<<"open /dev/sg90 failed" << endl;
    }
     qDebug()<<"open /dev/sg90 successfully " << endl;
}

void sg90_control(int angle)
{
    int ret;
    unsigned char data;
    data = angle;
    ret = write(fd3, &data, 1);

    if (ret < 0)
    {
        qDebug() <<"read /dev/sg90 failed" << endl ;
    }
}

int sg90_close()
{
    close(fd3);
}
