#include "mainwindow.h"

#include <QApplication>

#include <QMetaType>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // 注册自定义类型
    qRegisterMetaType<THData>("THData");

    MainWindow w;
    w.show();
    return a.exec();
}
