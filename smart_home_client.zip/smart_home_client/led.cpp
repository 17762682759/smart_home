#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <QDebug>
#include "led.h"


static int fd;

void led_init(void)
{
    fd = open("/dev/my_led", O_RDWR);
    if (fd < 0)
    {
        qDebug()<<"open /dev/my_led failed";
    }
    qDebug()<<"open /dev/my_led successfully " << endl;
}

void led_control(bool state)
{
    char buf;
    if (state)
    {
        buf = 1;
    }
    else
    {
        buf = 0;
    }
    write(fd, &buf, 1);
}

int led_close()
{
    close(fd);
}
