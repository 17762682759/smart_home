#ifndef LED_H
#define LED_H

void led_init(void);
void led_control(bool state);
int led_close();

#endif // LED_H
