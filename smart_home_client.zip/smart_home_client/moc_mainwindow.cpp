/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_DHT11Thread_t {
    QByteArrayData data[5];
    char stringdata0[43];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_DHT11Thread_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_DHT11Thread_t qt_meta_stringdata_DHT11Thread = {
    {
QT_MOC_LITERAL(0, 0, 11), // "DHT11Thread"
QT_MOC_LITERAL(1, 12, 17), // "DHT11_dataUpdated"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 6), // "THData"
QT_MOC_LITERAL(4, 38, 4) // "data"

    },
    "DHT11Thread\0DHT11_dataUpdated\0\0THData\0"
    "data"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_DHT11Thread[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   19,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,

       0        // eod
};

void DHT11Thread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<DHT11Thread *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->DHT11_dataUpdated((*reinterpret_cast< const THData(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (DHT11Thread::*)(const THData & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DHT11Thread::DHT11_dataUpdated)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject DHT11Thread::staticMetaObject = { {
    &QThread::staticMetaObject,
    qt_meta_stringdata_DHT11Thread.data,
    qt_meta_data_DHT11Thread,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *DHT11Thread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *DHT11Thread::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_DHT11Thread.stringdata0))
        return static_cast<void*>(this);
    return QThread::qt_metacast(_clname);
}

int DHT11Thread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void DHT11Thread::DHT11_dataUpdated(const THData & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
struct qt_meta_stringdata_SR04Thread_t {
    QByteArrayData data[5];
    char stringdata0[54];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SR04Thread_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SR04Thread_t qt_meta_stringdata_SR04Thread = {
    {
QT_MOC_LITERAL(0, 0, 10), // "SR04Thread"
QT_MOC_LITERAL(1, 11, 15), // "distanceUpdated"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 8), // "distance"
QT_MOC_LITERAL(4, 37, 16) // "sendDistanceData"

    },
    "SR04Thread\0distanceUpdated\0\0distance\0"
    "sendDistanceData"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SR04Thread[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   24,    2, 0x06 /* Public */,
       4,    1,   27,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,

       0        // eod
};

void SR04Thread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<SR04Thread *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->distanceUpdated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->sendDistanceData((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (SR04Thread::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SR04Thread::distanceUpdated)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (SR04Thread::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SR04Thread::sendDistanceData)) {
                *result = 1;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject SR04Thread::staticMetaObject = { {
    &QThread::staticMetaObject,
    qt_meta_stringdata_SR04Thread.data,
    qt_meta_data_SR04Thread,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *SR04Thread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SR04Thread::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SR04Thread.stringdata0))
        return static_cast<void*>(this);
    return QThread::qt_metacast(_clname);
}

int SR04Thread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void SR04Thread::distanceUpdated(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void SR04Thread::sendDistanceData(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
struct qt_meta_stringdata_LightCurtainThread_t {
    QByteArrayData data[8];
    char stringdata0[102];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_LightCurtainThread_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_LightCurtainThread_t qt_meta_stringdata_LightCurtainThread = {
    {
QT_MOC_LITERAL(0, 0, 18), // "LightCurtainThread"
QT_MOC_LITERAL(1, 19, 17), // "lightValueUpdated"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 5), // "value"
QT_MOC_LITERAL(4, 44, 19), // "curtainAngleChanged"
QT_MOC_LITERAL(5, 64, 5), // "angle"
QT_MOC_LITERAL(6, 70, 14), // "sendLightValue"
QT_MOC_LITERAL(7, 85, 16) // "sendCurtainAngle"

    },
    "LightCurtainThread\0lightValueUpdated\0"
    "\0value\0curtainAngleChanged\0angle\0"
    "sendLightValue\0sendCurtainAngle"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_LightCurtainThread[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   34,    2, 0x06 /* Public */,
       4,    1,   37,    2, 0x06 /* Public */,
       6,    1,   40,    2, 0x06 /* Public */,
       7,    1,   43,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    5,

       0        // eod
};

void LightCurtainThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<LightCurtainThread *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->lightValueUpdated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->curtainAngleChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->sendLightValue((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->sendCurtainAngle((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (LightCurtainThread::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&LightCurtainThread::lightValueUpdated)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (LightCurtainThread::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&LightCurtainThread::curtainAngleChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (LightCurtainThread::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&LightCurtainThread::sendLightValue)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (LightCurtainThread::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&LightCurtainThread::sendCurtainAngle)) {
                *result = 3;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject LightCurtainThread::staticMetaObject = { {
    &QThread::staticMetaObject,
    qt_meta_stringdata_LightCurtainThread.data,
    qt_meta_data_LightCurtainThread,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *LightCurtainThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *LightCurtainThread::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_LightCurtainThread.stringdata0))
        return static_cast<void*>(this);
    return QThread::qt_metacast(_clname);
}

int LightCurtainThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
    return _id;
}

// SIGNAL 0
void LightCurtainThread::lightValueUpdated(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void LightCurtainThread::curtainAngleChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void LightCurtainThread::sendLightValue(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void LightCurtainThread::sendCurtainAngle(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[20];
    char stringdata0[289];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 18), // "on_btn_led_clicked"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 11), // "updateChart"
QT_MOC_LITERAL(4, 43, 6), // "THData"
QT_MOC_LITERAL(5, 50, 4), // "data"
QT_MOC_LITERAL(6, 55, 14), // "updateDistance"
QT_MOC_LITERAL(7, 70, 8), // "distance"
QT_MOC_LITERAL(8, 79, 16), // "updateLightValue"
QT_MOC_LITERAL(9, 96, 5), // "value"
QT_MOC_LITERAL(10, 102, 18), // "updateCurtainAngle"
QT_MOC_LITERAL(11, 121, 5), // "angle"
QT_MOC_LITERAL(12, 127, 24), // "sendCurtainAngleToServer"
QT_MOC_LITERAL(13, 152, 24), // "sendCurtainAutoCtlStatus"
QT_MOC_LITERAL(14, 177, 22), // "on_btn_cur_sub_clicked"
QT_MOC_LITERAL(15, 200, 22), // "on_btn_cur_add_clicked"
QT_MOC_LITERAL(16, 223, 29), // "on_cb_curAutoCtl_stateChanged"
QT_MOC_LITERAL(17, 253, 5), // "state"
QT_MOC_LITERAL(18, 259, 9), // "readyRead"
QT_MOC_LITERAL(19, 269, 19) // "handleServerControl"

    },
    "MainWindow\0on_btn_led_clicked\0\0"
    "updateChart\0THData\0data\0updateDistance\0"
    "distance\0updateLightValue\0value\0"
    "updateCurtainAngle\0angle\0"
    "sendCurtainAngleToServer\0"
    "sendCurtainAutoCtlStatus\0"
    "on_btn_cur_sub_clicked\0on_btn_cur_add_clicked\0"
    "on_cb_curAutoCtl_stateChanged\0state\0"
    "readyRead\0handleServerControl"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   74,    2, 0x08 /* Private */,
       3,    1,   75,    2, 0x08 /* Private */,
       6,    1,   78,    2, 0x08 /* Private */,
       8,    1,   81,    2, 0x08 /* Private */,
      10,    1,   84,    2, 0x08 /* Private */,
      12,    1,   87,    2, 0x08 /* Private */,
      13,    0,   90,    2, 0x08 /* Private */,
      14,    0,   91,    2, 0x08 /* Private */,
      15,    0,   92,    2, 0x08 /* Private */,
      16,    1,   93,    2, 0x08 /* Private */,
      18,    0,   96,    2, 0x08 /* Private */,
      19,    1,   97,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QByteArray,    5,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_btn_led_clicked(); break;
        case 1: _t->updateChart((*reinterpret_cast< const THData(*)>(_a[1]))); break;
        case 2: _t->updateDistance((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->updateLightValue((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->updateCurtainAngle((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->sendCurtainAngleToServer((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->sendCurtainAutoCtlStatus(); break;
        case 7: _t->on_btn_cur_sub_clicked(); break;
        case 8: _t->on_btn_cur_add_clicked(); break;
        case 9: _t->on_cb_curAutoCtl_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->readyRead(); break;
        case 11: _t->handleServerControl((*reinterpret_cast< const QByteArray(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 12;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
