#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <QDebug>

#include "dht11.h"
static int fd1;

/* dht11初始化函数 */
void dht11_init(void)
{
    fd1 = open("/dev/my_dht11", O_RDWR);
    if (fd1 < 0)
    {
        qDebug()<<"open /dev/my_dht11 failed" << endl;
    }
     qDebug()<<"open /dev/my_dht11 successfully " << endl;
}

/* dht11读函数 */
int dht11_read(THData *data)
{
    unsigned char buf[4];
    int ret ;

    ret = read(fd1, buf, 4);

    if (ret < 0)
    {
        qDebug() <<"read /dev/my_dht11 failed" << endl ;
        return -1;
    }
    // 校验和验证
//    unsigned char checksum = buf[0] + buf[1] + buf[2] + buf[3];
//    if (checksum != buf[4]) {
//        qDebug() << "DHT11 checksum error!";
//        return -1;
//    }
    data->temperature = (double)buf[2];
    data->humidity = (double)buf[0];
    return 0;

}

int dht11_close()
{
    close(fd1);
}

