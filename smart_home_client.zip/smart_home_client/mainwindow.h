#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QChart>     //图表类
#include <QDateTime>
#include <QDebug>
#include <QPixmap>
#include <QValueAxis>
#include <QLineSeries>
#include <QString>
#include <QDebug>
#include "dht11.h"
#include "sr04.h"
#include "led.h"
#include "sg90.h"
#include <QThread>
#include <QCheckBox>
#include <QTcpSocket>


// /* 必需添加命名空间 */
// QT_CHARTS_USE_NAMESPACE

// DHT11传感器线程
class DHT11Thread : public QThread {
    Q_OBJECT

public:
    explicit DHT11Thread(QObject *parent = nullptr);
    ~DHT11Thread();

signals:
    void DHT11_dataUpdated(const THData &data);

protected:
    void run() override;

};

// 超声波传感器线程
class SR04Thread : public QThread {
    Q_OBJECT

public:
    explicit SR04Thread(QObject *parent = nullptr);
    ~SR04Thread();

signals:
    void distanceUpdated(int distance);
    void sendDistanceData(int distance);  // 新增信号


protected:
    void run() override;

};

// 光控窗帘线程
class LightCurtainThread : public QThread {
    Q_OBJECT

public:
    explicit LightCurtainThread(QObject *parent = nullptr);
    ~LightCurtainThread();

signals:
    void lightValueUpdated(int value);     // 光线值更新信号
    void curtainAngleChanged(int angle);  // 窗帘角度更新信号
    void sendLightValue(int value);       // 用于发送光线强度到服务端
    void sendCurtainAngle(int angle);     // 用于发送舵机角度到服务端

protected:
    void run() override;

private:
    int readLightSensor();                // 读取光敏电阻值
    int calculateCurtainAngle(int light); // 计算窗帘角度
};

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    bool LEDSwitch = false;

private:
    void setupChart();
    void connectToServer();
    void sendLedStatus();

private slots:
    void on_btn_led_clicked();
    void updateChart(const THData &data);
    void updateDistance(int distance);
    void updateLightValue(int value);
    void updateCurtainAngle(int angle);
    // void sendCurtainAngleToServer(int angle);
    // void sendCurtainAutoCtlStatus();
    void sendTHDataToServer(const THData &data);

    void on_btn_cur_sub_clicked();
    void on_btn_cur_add_clicked();
    void on_cb_curAutoCtl_stateChanged(int state);

    // void readyRead();
    void handleServerControl(const QByteArray &data); // 处理服务端控制指令


private:
    Ui::MainWindow *ui;
    DHT11Thread *dht11Thread;
    SR04Thread *sr04Thread;
    LightCurtainThread *curtainThread;
    QChart *chart;
    QLineSeries *tempSeries;
    QLineSeries *humiSeries;
    QValueAxis *axisX;
    QValueAxis *axisYTemp;
    QValueAxis *axisYHumi;
    QTcpSocket *socket;
};


#endif // MAINWINDOW_H
